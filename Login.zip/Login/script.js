const form =document.getElementById("loginForm");
const email = document.getElementById("email");
const password = document.getElementById("password");

form.addEventListener("submit",function(e){
    e.preventDefault();
    validateForm();
});

function validateForm(){
    let valid = true;

    // Email valiadtion
    if(email.value.trim()===""){
        showError(email, "Email is required");
        valid = false;
    }else if (!isvalidEmail(email.value)){
        showError(email,"Enter a valid email");
        valid = false;
    }else{
        showSuccess(email);
    }

    //password validation
    if(password.value.trim() === ""){
        showError(password, "Password is required");
        valid = false;
    }else if (password.value.length<6){
        showError(password, "Minimum 6 Charaters required");
        valid = false;
    }else{
        showSuccess(password);
    }

    if(valid){
        alert("Login Successful!");
        form.requestFullscreen();
    }
}

function showError(input,message){
    const error=input.nextElementsibling;
    error.innerText= message;
    input.style.bordercolor = "red";
}

function showSuccess(input){
    const error = input.nextElementsibling;
    error.innerText = "";
    input.style.bordercolor="green";
}

function isvalidEmail(email){
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}